export const boardTasks = [
	{
		id: '1',
		title: 'ААААА',
		status: 'todo',
	},
	{
		id: '2',
		title: 'Помогите',
		status: 'todo',
	},
	{
		id: '3',
		title: 'Я выживу',
		status: 'todo',
	},

	{
		id: '4',
		title: 'ААААААААААААААА',
		status: 'in-progress',
	},
	{
		id: '5',
		title: 'Курсач',
		status: 'in-progress',
	},

	{
		id: '6',
		title: 'КАК',
		status: 'done',
	},
	{
		id: '7',
		title: 'ааа',
		status: 'done',
	},

	{
		id: '8',
		title: 'АААААААААА',
		status: 'removed',
	},
	{
		id: '9',
		title: 'ф',
		status: 'removed',
	},
	{
		id: '10',
		title: 'Грустно',
		status: 'removed',
	},
]
