export const TaskStatusMap = {
	todo: 'Бэклог',
	'in-progress': 'В процессе',
	done: 'Готово',
	removed: 'Корзина',
}
